Placeholder. TODO(backend): replayer source.
